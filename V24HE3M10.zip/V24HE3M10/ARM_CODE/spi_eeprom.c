#include "header.h"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
void Cmd_25LC512(u8 cmd)
{
	IOCLR0=CS;
	SPI0(cmd);
	IOSET0=CS;
}

void ByteWrite_25LC512(u16 addr,u8 dat)
{
	Cmd_25LC512(WREN);
	IOCLR0=CS;
	SPI0(WRITE);
	SPI0(addr>>8);
	SPI0(addr);
	SPI0(dat);
	IOSET0=CS;
	delay_ms(10);
	Cmd_25LC512(WRDI);
}

u8 ByteRead_25LC512(u16 addr)
{
	u8 dat;
	//Cmd_25LC512(READ);
	IOCLR0=CS;
	SPI0(READ);
	SPI0(addr>>8);
	SPI0(addr);
	dat=SPI0(0X00);
	IOSET0=CS;
	return dat;
}

void PageWrite_25LC512(u16 pageStartAddr,char *ptr128Bytes)
{
	Cmd_25LC512(WREN);
	IOCLR0=CS;
	SPI0(WRITE);
	SPI0(pageStartAddr>>8);
	SPI0(pageStartAddr);
	while(*ptr128Bytes)
		SPI0(*ptr128Bytes++);
	SPI0(*ptr128Bytes++);
	IOSET0=CS;
	delay_ms(10);
	Cmd_25LC512(WRDI);
}

void PageRead_25LC512(u16 pageStartAddr,char *str)
{
	u32 l=0;
	u8 dat;
	IOCLR0=CS;
	SPI0(READ);
	SPI0(pageStartAddr>>8);
	SPI0(pageStartAddr);
	dat=SPI0(0x00);
	while(dat)
	{
		str[l++]=dat;
		dat=SPI0(0x00);
  }
	str[l]=dat;
	IOSET0=CS;
	delay_ms(10);
	Cmd_25LC512(WRDI);
}






