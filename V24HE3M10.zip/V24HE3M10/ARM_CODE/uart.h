void InitUART0 (void); /* Initialize Serial Interface       */ 
void UART0_Tx(char ch);  
char UART0_Rx(void);    
void UART0_Tx(char ch);
void UART0_Int(unsigned int n);
void UART0_Float(float f);
void UART0_Str(char *s);

void InitUART1 (void); /* Initialize Serial Interface       */ 
void UART1_Tx(char ch);  
char UART1_Rx(void);    
void UART1_Tx(char ch);
void UART1_Int(unsigned int n);
void UART1_Float(float f);
void UART1_Str(char *s);
