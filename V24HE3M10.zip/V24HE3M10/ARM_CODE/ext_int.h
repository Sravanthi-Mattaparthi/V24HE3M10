void Enable_EINT0(void);
void Enable_EINT1(void);
