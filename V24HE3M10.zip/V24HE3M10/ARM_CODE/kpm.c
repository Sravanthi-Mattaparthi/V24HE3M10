#include "kpm.h"
#include "kpm_defines.h"
#include "defines.h"
#include<LPC21xx.h>

u8 kpmLUT[4][4]={{'1','2','3','A'},{'4','5','6','B'},{'7','8','9','C'},{'*','0','#','D'}};

u32 ColScan(void)
{
        return(((READNIBBLE(IOPIN1,COL0))<15)?0:1);
}

u32 RowCheck(void)
{
        u32 rNo;
        for(rNo=0;rNo<=3;rNo++)
        {
                WRITENIBBLE(IOPIN1,ROW0,(~(1<<rNo)));
                if(ColScan()==0)
                        break;
        }
        WRITENIBBLE(IOPIN1,ROW0,0);
        return rNo;
}
u32 ColCheck(void)
{
        u32 cNo;
        for(cNo=0;cNo<=3;cNo++)
        {
                if((READBIT(IOPIN1,(COL0+cNo)))==0)
                        break;
        }
        return cNo;
}

u32 KeyScan(void)
{
        u32 keyV,rNo,cNo;
        while(ColScan());
        rNo=RowCheck();
        cNo=ColCheck();
        keyV=kpmLUT[rNo][cNo];
        return keyV;
}

void Init_KPM(void)
{
        WRITENIBBLE(IODIR1,ROW0,15);
				WRITENIBBLE(IOCLR1,ROW0,15);
}
