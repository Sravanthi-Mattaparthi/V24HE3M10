#include "header.h"
#define LED_4AH_AL 16
#define EINT0_VIC_CHNO  14
#define EINT1_VIC_CHNO  15
#define EINT0_PIN        1
#define EINT1_PIN        3

extern int exint;

void eint1_isr(void) __irq
{
	if(exint==0)
	{
  char pass[10],str[10],cpass[10];
	u8 s;
	int y=3,z,d,x=3,w=3;
	
	//Write the user requirement task
	while(y--)
	{
		CmdLCD(CLEAR_LCD);
		SetCursor(1,0);
		StrLCD("1.CHANGE PWD");
		SetCursor(2,0);
		StrLCD("2.RESET  3.EXIT");
		s=KeyScan();
		d=s-48;
		while(ColScan()==0);
		if(d==1)
		{
			for(z=0;z<3;z++)
			{
				SetCursor(1,0);
				CmdLCD(CLEAR_LCD);
				StrLCD("ENTER OLD PWD");
				SetCursor(2,0);
				password(pass);
				PageRead_25LC512(0,str);
				CmdLCD(CLEAR_LCD);
				if(strcmp(pass,str)==0)
				{
					SetCursor(1,0);
					w=3;
				a:CmdLCD(CLEAR_LCD);
					StrLCD("ENTER NEW PWD");
					SetCursor(2,0);
					password(pass);
					if(strcmp(pass,str)==0)
					{
						CmdLCD(CLEAR_LCD);
						StrLCD("NEW PWD DOES NOT");
						SetCursor(2,0);
						StrLCD(" MATCH WITH OLD");
						delay_ms(500);
						if(w>0)
						{
							w--;
							goto a;
						}
						else
							break;
					}
					while(x--)
					{
						CmdLCD(CLEAR_LCD);
						StrLCD("CONFIRM NEW PWD");
						SetCursor(2,0);
						password(cpass);
						if(strcmp(pass,cpass)==0)
						{
							PageWrite_25LC512(0,pass);
							CmdLCD(CLEAR_LCD);
							StrLCD(" PASSWORD SAVED");
							SetCursor(2,2);
							StrLCD("SUCCESSFULLY");
							delay_ms(500);
							break;
						}
						else
						{
							CmdLCD(CLEAR_LCD);
							StrLCD("CONFIRM PASSWORD");
							SetCursor(2,0);
							StrLCD("NOT SAME TO NEW");
							delay_ms(400);
						}
					}
					break;
				}
				else
				{
					CmdLCD(CLEAR_LCD);
					StrLCD("INCORRECT PWD");
					delay_ms(500);
				}
			}
		}
		else if(d==2)
		{
			PageWrite_25LC512(0,"12345");
			CmdLCD(CLEAR_LCD);
			StrLCD(" PASSWORD RESET");
			SetCursor(2,2);
			StrLCD("SUCCESSFULLY");
			delay_ms(500);
		}
		else if(d==3)
		{
			CmdLCD(CLEAR_LCD);
			StrLCD("    EXITING");
			delay_ms(500);
			break;
		}
		else
		{
			CmdLCD(CLEAR_LCD);
			StrLCD("INVALID INPUT");
			delay_ms(500);
		}
	}
	CmdLCD(CLEAR_LCD);
	SetCursor(1,0);
	StrLCD("LIBRARY MANAGING");
	SetCursor(2,4);
	StrLCD("SYSTEM");
}
	//Clear eint0 flag
  EXTINT=1<<1;
	//Clear eint0 flag in VIC
	VICVectAddr=0;
}
/*
void eint0_isr(void) __irq
{
       // u32 k,i;
        //Write the user requirement task
        //Clear eint1 flag
        EXTINT=1<<0;
        //Clear eint1 flag in VIC
        VICVectAddr=0;
}

void Enable_EINT0(void)
{
        // Configure the EINT0(external interrupt) function to the port pin(P0.1). 
        cfgportpin(0,EINT0_PIN,PIN_FUNC4);
        //enable eint0 via VIC
        VICIntEnable|=1<<EINT0_VIC_CHNO;
				//cfg eint0 as Vectored IRQ with priority
        VICVectCntl3=(1<<5)|EINT0_VIC_CHNO;
				//load eint0_isr address into VIC LUT
        VICVectAddr3=(u32)eint0_isr;
				//cfg eint0 in external interrupt peripheral

				//cfg eint0 for edge triggering
        EXTMODE=1<<0;
				//cfg eint0 for rising edge or falling edge
}
*/
void Enable_EINT1(void)
{
        // Configure the EINT1(external interrupt) function to the port pin(P0.3).
        cfgportpin(0,EINT1_PIN,PIN_FUNC4);
        //enable eint1 via VIC
        VICIntEnable|=1<<EINT1_VIC_CHNO;
        //cfg eint1 as Vectored IRQ with priority
        VICVectCntl2=(1<<5)|EINT1_VIC_CHNO;
				//load eint1_isr address into VIC LUT
        VICVectAddr2=(u32)eint1_isr;
				//cfg eint1 in external interrupt peripheral
				//cfg eint1 for edge triggering
        EXTMODE=1<<1;
				//cfg eint1 for rising edge or falling edge
}
