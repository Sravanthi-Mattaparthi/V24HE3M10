#include "header.h"

extern char arr[20],dummy1;
extern char buff[20],dummy;
extern unsigned char i,ch,r_flag;
extern unsigned char j,c,r_flag1;

void user(void)
{
	int ux;
	ux=1;
	while(ux)
	{
		CmdLCD(CLEAR_LCD);
		SetCursor(1,0);
		StrLCD("WAITING FOR USER");
		SetCursor(2,5);
		StrLCD("CHOICE");
		delay_ms(500);
		r_flag=0;
		while(r_flag==0);
		if(ch=='1')
		{
			CmdLCD(CLEAR_LCD);
			StrLCD("SCAN ISSUE BOOK");
			j=0;r_flag1=0;
			while(r_flag1==0);
			SetCursor(2,0);
			UART0_Str(arr);
			StrLCD(arr);
			r_flag=0;
			while(r_flag==0);
			if(ch=='T')
			{
				CmdLCD(CLEAR_LCD);
				StrLCD("  BOOK ISSUED");
				SetCursor(2,2);
				StrLCD("SUCCESSFULLY");
				delay_ms(500);
			}
			else if(ch=='F')
			{
				CmdLCD(CLEAR_LCD);
				StrLCD("INVALID CARD");
				delay_ms(500);
			}
		}
		else if(ch=='2')
		{	
			CmdLCD(CLEAR_LCD);
			StrLCD("SCAN RETURN BOOK");
			j=0;r_flag1=0;
			while(r_flag1==0);
			SetCursor(2,0);
			UART0_Str(arr);
			StrLCD(arr);
			r_flag=0;
			while(r_flag==0);
			if(ch=='T')
			{
				CmdLCD(CLEAR_LCD);
				StrLCD("  BOOK RETURN");
				SetCursor(2,2);
				StrLCD("SUCCESSFULLY");
				delay_ms(500);
			}
			else if(ch=='F')
			{
				CmdLCD(CLEAR_LCD);
				StrLCD("INVALID CARD");
				delay_ms(500);
			}
		}
		else if(ch=='3')
		{
			ux=0;
			CmdLCD(CLEAR_LCD);
			StrLCD("    EXITING");
			delay_ms(500);
		}
		
	}
}
			
		




