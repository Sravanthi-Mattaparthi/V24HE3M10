#ifndef __SPI_EEPROM_DEFINES_H__
#define __SPI_EEPROM_DEFINES_H__

//Instruction
#define READ      0X03
#define WRITE    0X02
#define WRDI      0X04
#define WREN      0x06

#endif
