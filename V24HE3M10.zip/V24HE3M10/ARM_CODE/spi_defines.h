#ifndef __SPI_DEFINES_H__
#define __SPI_DEFINES_H__

//defines for SPI0 pin function select 
#define SCK     4
#define MISO    5
#define MOSI    6
#define CS      (1<<7)

//Control Rgister Bits setting
#define Mode_0 0X00  //CPOL=0 CPHA==0
#define Mode_1 0X08  //CPOL=0 CPHA==1
#define Mode_2 0X10  //CPOL=1 CPHA==0
#define Mode_3 0X18  //CPOL=1 CPHA==1
#define MSTR   (1<<5)
#define LSBF   (1<<6)

//Status Register bits
#define SPIF   (1<<7)  //Data Transfer Completion Flag

#endif
