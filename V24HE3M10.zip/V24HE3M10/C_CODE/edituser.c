#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void edituser(void)
{
	USER *temp=NULL,*prev=NULL;
	printf("\nEnter the editing user card number:");
     	__fpurge(stdin);
	ptr[0]='\0';
	scanf("%[^\n]s",ptr);
	if(strlen(ptr)!=8)
	{
		printf(RED"\nInvalid card\n"COLROFF);
		return;
	}
	for(int i=0;ptr[i];i++)
        {
                if(ptr[i]>=48 && ptr[i]<=57)
                {
                        continue;
                }
                else
                {
                        printf(RED"\nINVALID CARD\n"COLROFF);
                        return;
                }
        }

	temp=head;
	while(temp!=NULL)
	{
		char s[10];

               if(strcmp(ptr,lib_card)==0)
                    {
                        printf(YELLOW"***** This is librarian card,Editing is not allowed *****\n"COLROFF);
                        return;
                    }


		if(strcmp(ptr,temp->uid)==0)
		{
                   a:printf("\nEnter the new user name for edit:");
			s[0]='\0';
			__fpurge(stdin);
			scanf("%[^\n]s",s);
			if(strlen(s)>=19)
			{
				printf(RED"\n Invalid User Name\n"COLROFF);
	puts(YELLOW"*****You entered beyond the size****\n*****please enter less then 20 characters*****"COLROFF);
				goto a;
			}
			if(s[0]!='\0')
			{
				strcpy(temp->uname,s);
				printf(BLUE"\nUser details edited successfully\n"COLROFF);
				return;
			}
			else
			{
				printf(BLUE"\nUser Not Edited\n"COLROFF);
				return;
			}
		}
		prev=temp;
		temp=temp->link;
	}
	printf(RED"\nNo user with that card\n"COLROFF);
}

