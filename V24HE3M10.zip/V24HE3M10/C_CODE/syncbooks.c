#include "header.h"
/*
#include<stdio.h>
#include<stdlib.h>
#include<string.h>*/

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

void syncbooks(void)
{
	STORE *newnode=NULL,*temp1=NULL;
	char str[50],*p;
	int n,m=0;
	FILE *fp;
	fp=fopen("books.csv","r");
	if(fp==NULL)
	{
		printf(RED"No books in library\n"COLROFF);
		return ;
	}
	while(fgets(str,50,fp))
	{
		newnode=calloc(1,sizeof(STORE));
		if(newnode==NULL)
		{
			printf("Node not created\n");
			exit(0);
		}
		p=str;
		p=strtok(p,",");
		strcpy(newnode->bid,p);
		p=strtok(NULL,",");
		strcpy(newnode->bname,p);
		p=strtok(NULL,",");
		newnode->b_stat=*p;
		if(head1==NULL)
		{
			head1=newnode;
		}
		else
		{
			newnode->link=head1;
			head1=newnode;
		}
	}
	fclose(fp);
	return;
}




