#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

void saveuser(void)
{
	USER *temp=NULL;
	BOOK *temp1=NULL;
	FILE *fp=NULL;
	fp=fopen("user.csv","w");
	if(fp==NULL)
	{
		printf(RED"\nFile not created\n"COLROFF);
		exit (0);
	}
	temp=head;
	while(temp!=NULL)
	{
		fprintf(fp,"%s,%s,%hd,",temp->uid,temp->uname,temp->cnt);
		temp1=temp->ubook;
		for(int i=0;i<temp->cnt;i++)
		{
			fprintf(fp,"%s,%s,%ld,",temp1->tid,temp1->tname,temp1->t);
			temp1=temp1->link;
		}
		temp=temp->link;
		fprintf(fp,"\n");
	}
	fclose(fp);
}


