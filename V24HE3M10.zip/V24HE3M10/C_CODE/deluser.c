#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void deluser(void)
{
	USER *temp=NULL,*prev=NULL;
	printf("\nEnter the deleting user card number:");
	__fpurge(stdin);
	ptr[0]='\0';
	scanf("%[^\n]s",ptr);
	if(strlen(ptr)!=8)
	{
		printf(RED"\nInvalid card\n"COLROFF);
		return;
	}
	for(int i=0;ptr[i];i++)
        {
                if(ptr[i]>=48 && ptr[i]<=57)
                {
                        continue;
                }
                else
                {
                        printf(RED"\nInvalid card\n"COLROFF);
                        return;
                }
        }

	temp=head;
	while(temp!=NULL)
	{
		if(strcmp(ptr,lib_card)==0)
                {
                        printf(YELLOW"\n***** You can't delete librarian *****\n"COLROFF);
                        return;
                }
		if(strcmp(ptr,temp->uid)==0)
		{
			if(temp->cnt>0)
			{
				printf(BLUE"\nUser has books to return,First return and delete the user\n"COLROFF);
				return;
			}
			if(temp==head)
			{
				head=temp->link;
				free(temp);
			}
			else
			{
				prev->link=temp->link;
				free(temp);
			}
			printf(BLUE"\nUser deleted successfully\n"COLROFF);
			return;
		}
		prev=temp;
		temp=temp->link;
	}
	printf(RED"\nNo user with that card\n"COLROFF);
}

