#include <stdint.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <stdio_ext.h>
#include <time.h>
#include<signal.h>

//Librarian card number as macro
#define lib_card "12540123"


//Color codes for printing statements

#define RED        "\e[1;5;31m"
#define GREEN      "\e[1;32m"
#define YELLOW     "\e[1;5;33m"
#define BLUE        "\e[1;34m"
#define PUR        "\e[1;35m"
#define COLROFF        "\e[m"



//#define SERIALPORT  1

typedef struct book
{
	char tid[10];
	char tname[20];
	time_t t;
	struct book *link;
}BOOK;

typedef struct user
{
	char uid[10];
	char uname[30];
	short int cnt;
	BOOK *ubook;
	struct user *link;
}USER;

typedef struct store
{
	char bid[10];
	char bname[30];
	char b_stat;
	struct store *link;
}STORE;

#ifndef _UART_H_
#define _UART_H_

int   serialOpen      (const char *device, const int baud) ;
void  serialClose     (const int fd) ;
void  serialFlush     (const int fd) ;
void  serialPutchar   (const int fd, const unsigned char c) ;
int   serialGetchar   (const int fd) ;
int   serialGetstr    (const int fd,char *ptr);
void  serialPutstr    (const int fd,char *str);

void libmenu(void);
void adduser(void);
void deluser(void);
void dispstat(void);
void addbook(void);
void delbook(void);
void edituser(void);
void editbook(void);
void issuebook(USER *);
void returnbook(USER *);
void savebook(STORE *head1);
void saveuser(void);
void syncbooks(void);
void syncuser(void);
char *remv(char *p);

#endif


