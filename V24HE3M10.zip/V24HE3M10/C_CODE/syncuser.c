#include "header.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

extern USER *head;
extern STORE *head1;
extern BOOK *head2;
/*
USER *head;
STORE *head1;
BOOK *head2;

char *remv(char *p)
{
        p[strlen(p)-1]='\0';
        return p;
}
*/
long int change(char *p)
{
	int i=0,j;
	long int n=0;
	while(p[i])
	{
		j=p[i]-48;
		n=(n*10)+j;
		i++;
	}
	return n;
}

//int main(void)
void syncuser(void)
{
	USER *newnode=NULL,*temp=NULL;
	BOOK *newnode1=NULL,*temp2=NULL;
	char str[200],*p;
	int n,m=0;
	FILE *fp;
	fp=fopen("user.csv","r");
	if(fp==NULL)
	{
		printf(RED"No users in library\n"COLROFF);
		return ;
	}
	while(fgets(str,200,fp))
	{
		newnode=calloc(1,sizeof(USER));
		if(newnode==NULL)
		{
			printf("Node not created\n");
			exit(0);
		}
		p=str;
		p=strtok(p,",");
		strcpy(newnode->uid,p);
		p=strtok(NULL,",");
		strcpy(newnode->uname,p);
		p=strtok(NULL,",");
		newnode->cnt=(*p)-48;
		for(int i=0;i<newnode->cnt;i++)
		{
			newnode1=calloc(1,sizeof(BOOK));
			if(newnode1==NULL)
			{
				printf("Node not created\n");
				exit(0);
			}
			p=strtok(NULL,",");
                	strcpy(newnode1->tid,p);
                	p=strtok(NULL,",");
                	strcpy(newnode1->tname,p);
                	p=strtok(NULL,",");
			long int d;
			d=change(p);
                	newnode1->t=d;
			if(newnode->ubook==NULL)
				newnode->ubook=newnode1;
			else
			{
				newnode1->link=newnode->ubook;
				newnode->ubook=newnode1;
			}
		}
		if(head==NULL)
		{
			head=newnode;
		}
		else
		{
			newnode->link=head;
			head=newnode;
		}
	}
	fclose(fp);
	return;
}

