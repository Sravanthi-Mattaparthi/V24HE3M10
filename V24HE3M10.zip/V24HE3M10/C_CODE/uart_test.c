/*main.c: Very simple program to test the serial port. Expects the port to be looped back to itself */



#include "header.h"

USER *head=NULL;
STORE *head1=NULL;

int main ()
{
	int fd,flag;
	char tx,rx ;
	char str[20],ptr[20];

	puts("Opening serial port\n");

	{	
	if ((fd = serialOpen ("/dev/ttyUSB0",9600)) < 0)
	{

		fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
		return 1 ;
	}

	puts("serial port is opened\n");

	usleep(1000000);
	}

	for (tx = 'A' ; tx <'A'+26 ;tx++ )
	{
		serialPutchar(fd, tx) ;
		printf("sent  : %c\n",tx);
		rx=serialGetchar(fd);
		printf ("recvd : %c\n",rx) ;
		usleep(100000);
		system("clear");
	}

	printf("Enter the string");
	__fpurge(stdin);
        scanf("%[^\n]s",str);
        serialPutstr(fd,str);
	serialGetstr(fd,ptr);
	puts(ptr);
	while(1)
	{
		tx='R';
		write(fd,&tx,1);
		usleep(10);
        	serialGetstr(fd,ptr);
        	puts(ptr);
	}
        if(strcmp(ptr,str)==0)
		printf("correct\n");
	else
		printf("Incorrect");
}

