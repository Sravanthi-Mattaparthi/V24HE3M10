


#include "header.h"

USER *head=NULL;
STORE *head1=NULL;
BOOK *head2=NULL;

int fd,flag;
char tx,rx ;
char ptr[10];
void my_handler(int sig)
{
	tx='F';
	sleep(1);
	write(fd,&tx,1);
	puts("'SIGINT' handled Successfully");
	exit(0);
}
void my_handler1(int sig)
{
        tx='F';
        sleep(1);
        write(fd,&tx,1);
        puts(RED"\nSudden termination handled successfully"COLROFF);
        exit(0);
}
int main ()
{
	int i,choice;
	syncbooks();
	syncuser();
	signal(SIGINT,my_handler);
	signal(SIGABRT,my_handler1);
	signal(SIGTERM,my_handler1);
	puts("Opening serial port\n");
	{	
		if ((fd = serialOpen ("/dev/ttyUSB0",9600)) < 0)
		{
			fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
			return 1 ;
		}
		puts("serial port is opened\n");
		printf(YELLOW"\t\tWELCOME TO LIBRARY MANAGEMENT SYSTEM\t\t\n"COLROFF);
		printf("\t----------------------------------------------------\t\n");
		printf(PUR"\n\t\tPLEASE FOLLOW THE INSTRUCTIONS CAREFULLY\t\t\n"COLROFF);
		usleep(1000);
	}

	while(1)
	{
		serialFlush(fd);
		serialFlush(fd);
		a:printf(GREEN"\nEnter '1' to place the card\nEnter '2' to Exit\n"COLROFF);
  		__fpurge(stdin);
 	 	scanf("%d",&i);
  		if(i==1)
  		{
	  		tx='R';
	  		sleep(1);
			write(fd,&tx,1);
			flag=0;
			printf("\nWaiting for the Card Scan....\n");
#ifdef SERIALPORT
	  {
		  printf("\nEnter the card details:");
		  __fpurge(stdin);
		  scanf("%[^\n]s",ptr);
	  }
#else
	  serialGetstr(fd,ptr);
#endif
			puts(ptr);
	 		if(strcmp(ptr,lib_card)==0)
	  		{
		  	puts("librarian card");
		  flag=1;
		  tx='L';
		  sleep(1);
		  write(fd,&tx,1);
		  printf("\nsending:L\n");
#ifdef SERIALPORT
		  {
			  printf("\nEnter the choice T/F:");
			  __fpurge(stdin);
			  scanf("%c",&rx);
		  }
#else	
		  puts("enter the password in LPC2148's keypad");
		  read(fd,&rx,1);
#endif
		  __fpurge(stdin);
		  if(rx=='T')
		  {
			  libmenu();
		  }
		  else
		  {
			  printf(RED"\nInvalid password\n"COLROFF);
		  }
		  tx='F';
		  sleep(1);
		  write(fd,&tx,1);
	  }
	  else
	  {
		  USER *temp=NULL;
		  temp=head;
		  while(temp!=NULL)
		  {
			  if(strcmp(temp->uid,ptr)==0)
			  {
				  flag=1;
				  tx='U';
				  sleep(1);
				  write(fd,&tx,1);
				  puts("user card");
				  printf("\nsending:U\n");
b:printf(GREEN"\n1.ISSUE BOOK / 2.RETURN BOOK / 3.EXIT\n"COLROFF);
  printf("\nEnter the choice:");
  __fpurge(stdin);
  scanf("%d",&choice);
  if(choice==1)
  {
	  issuebook(temp);
	  goto b;
  }
  else if(choice==2)
  {
	  returnbook(temp);
	  goto b;
  }
  else if(choice==3)
  {
	  tx='3';
	  sleep(1);
	  write(fd,&tx,1);
	  goto a;
  }
  else
  {
	  printf(RED"\nINVALID INPUT\n"COLROFF);
	  goto b;
  }
			  }
			  temp=temp->link;
		  }
	  }
	  if(flag==0)
	  {
		  tx='N';
		  sleep(1);
		  write(fd,&tx,1);
		  printf(RED"\nInvalid card\n"COLROFF);
	  }
  }
  else if(i==2)
	  break;
  else
	  printf(RED"\nInvalid input\n"COLROFF);
	}
	saveuser();
	savebook(head1);
	serialClose(fd);
	puts(BLUE"Closing serial port"COLROFF);
	return 0 ;
}

