#include "header.h"

extern USER *head;
extern STORE *head1;
extern BOOK *head2;

extern int fd,flag;
extern char tx,rx ;
extern char ptr[10];

void addbook(void)
{
	STORE *temp=NULL,*newnode=NULL;
	USER *temp1=NULL;
	printf("\nEnter the new book card number:");
       	__fpurge(stdin);
	ptr[0]='\0';
	scanf("%[^\n]s",ptr);
	if(strlen(ptr)!=8)
	{
		printf(RED"Invalid Card\n"COLROFF);
		return;
	}
	for(int i=0;ptr[i];i++)
        {
                if(ptr[i]>=48 && ptr[i]<=57)
                {
                        continue;
                }
                else
                {
                        printf(RED"\nINVALID CARD\n"COLROFF);
                        return;
                }
        }
//extra test case added
	temp1=head;
        while(temp1!=NULL)
        { 
              if(strcmp(ptr,lib_card)==0)
                {
                        printf(YELLOW"\n***** This  is librarian card,can't assign to as book id *****\n"COLROFF);
                        return;
                }
                    
                if(strcmp(ptr,temp1->uid)==0)
                {
                        printf(YELLOW"\n***** This is user card can't assign to as book id *****\n"COLROFF);
                        return;
                }
		

                temp1=temp1->link;
        }

	temp=head1;
	while(temp!=NULL)
	{
		if(strcmp(ptr,temp->bid)==0)
		{
			printf(BLUE"\n<<< Book already exists :( >>>\n"COLROFF);
			return;
		}
		temp=temp->link;
	}
	newnode=calloc(1,sizeof(BOOK));
	if(newnode==NULL)
		printf(RED"\nNode not created\n"COLROFF);
	else
	{
		char s[20];
		strcpy(newnode->bid,ptr);
	      a:printf("\nEnter the new book name:");
		s[0]='\0';
		__fpurge(stdin);
		scanf("%[^\n]s",s);
		if(strlen(s)>=19)
                {
                        printf(RED"\nInvalid Book Name\n"COLROFF);
		puts(YELLOW"****you enter beyond the size****\n****plese enter the less thar 20 char****"COLROFF);
                        goto a;
                }
		if(s[0]!='\0')
		{
			strcpy(newnode->bname,s);
	
		}
		else
		{
			
			printf(RED"\nInvalid Book Name\n"COLROFF);
			goto a;
		}
		newnode->b_stat='Y';
		newnode->link=head1;
		head1=newnode;
	}
	printf(BLUE"\n <<< New book created successfully :) \n"COLROFF);
}

